# Issue 36: T5A (HW4.0 only)

Unzip on the computer, install only the BIN, then check `$VER,v2026.11.10-T5A,HW4.0`.
Compare with T4A. At 100/200/500 us/div in live Y-T, the MCU still draws into
RAM, but sends pending pixels to the panel only after a completed capture is
read and before rearming. The LCD may show the previous frame. This isolates
MCU-to-LCD transfers, not the panel's internal refresh. T4A's PB3 software
read clock, trigger rules, 5/10/25 ms post-arm waits and USB data are unchanged.

1. Repeat the last swapped-input run at 500 us/div: CH1 shorted to scope
   ground, CH2 on the built-in 1 kHz sine, both at 2 V/div, Y-T and the same
   free-running AUTO trigger and DDS amplitude as T4A. Re-enable DDS after
   flashing. Close menus and discard the first three frames after setup.
2. Log at least 25 distinct frame IDs. If practical, swap the inputs back
   (CH1 sine, CH2 grounded) and repeat at 500 us/div. Optionally repeat at
   100 and 200 us/div. Label each log with its wiring and timebase.
3. Attach the plain-text USB log including `$VER`, `$GEN`, `$SCOPE`,
   `$CH2RAW`, `$TAIL`, and both `$WAVE` lines when available. We are checking
   whether the CH2 jumps at samples 2032-2046 and the last sample (2047)
   returning to the CH1 level change independently. No extra USB command.
