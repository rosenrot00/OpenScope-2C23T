# Issue 36: HW4 PB3 read-clock A/B test

**HW4.0 only. Unzip on your computer and install just ONE BIN at a time.**

| Build | Full-buffer PB3 read clock |
| --- | --- |
| T4A (control) | T3R's original software delay |
| T4B (experiment) | Stock 2.1.0's TMR7 divider of 239 and one counter tick after each PB3 edge |

Both builds have identical tail telemetry. FPGA writes, the trigger, and the
5/10/25 ms post-arm pauses at 100/200/500 us/div are unchanged.

1. Flash A first and verify `$VER,v2026.11.10-T4A,HW4.0`. Start the built-in
   1 kHz DDS sine on CH1, short CH2 directly to scope ground, and keep both at
   2 V/div in Y-T mode. Use the same generator amplitude and trigger as before.
2. Log at least 22 distinct frame IDs at 500 us/div. Please also record about
   20 at 100 and 200 us/div as controls. No extra USB command is needed.
3. Repeat with B (`$VER,v2026.11.10-T4B,HW4.0`) and the same setup. Re-enable
   the generator after updating. Please share one plain-text USB log per build
   including `$VER`, `$SCOPE`, `$CH2RAW`, `$TAIL` and `$WAVE,2` when available.
   Do not match numeric frame IDs *between* runs; they are local to each run.

```text
$TAIL,frame_id,2032,CH1_hex,CH2_hex
```

Each hex field holds 16 unsigned raw ADC bytes in acquisition order: first
byte = sample 2032, last byte = sample 2047. The 13th and 14th bytes are
samples 2044 and 2045. Samples 2046 and 2047 are transmitted too, even
though the Vpp calculation excludes them. The ID matches the accompanying
`$CH2RAW` line; repeated IDs are not new captures.

We are testing whether the CH2 peaks at 2044/2045 remain with the stock
read timing and whether CH1 shows a disturbance at the same indices.
